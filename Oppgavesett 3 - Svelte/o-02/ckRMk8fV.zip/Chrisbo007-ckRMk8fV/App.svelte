<script>
let forrett = ""
let hovedrett =""
let dessert = ""

</script>
	
	<input bind:value={forrett} placeholder="Skriv din forrett">
	<input bind:value={hovedrett} placeholder="Skriv din hovedrett">
	<input bind:value={dessert} placeholder="Skriv din dessert">
	
	<h1>Din vegetarmeny</h1>
	<ul>
		<li>{forrett}</li>
		<li>{hovedrett}</li>
		<li>{dessert}</li>
	</ul>
	
	
<style>
	h1 {
		color: green;
	}
		ul {
			color: purple;
			font-style: Georgia;
		}
</style>