<script>
	let title = "";
	let text = "";
</script>

<input bind:value={title} placeholder="Tittel">
<input bind:value={text} placeholder="En tekst om moby Dick">
<a href="moby.html"> Les mer her </a>

<h1>{title}</h1>
<p>{text}</p>

<style>
</style>


