<script>
let size = 40;
let type = "";
let color = "";
let background ="";	
let text ="";

</script>




<main style="background-color: {background}">
	<p>Velg bakgrunnsfarge:</p>
	<input type="color" bind:value={background}>
	<p>Juster Skriftstørrelsen:</p>
	<input type="range" bind:value={size}>
	<p>Juster fargen på teksten:</p>
	<input type="color" bind:value={color}>
	<p>Velg skrift-type:</p>
	<select bind:value={type}>
		<option value="arial">Arial</option>
		<option value="georgia">Georgia</option>
		<option value="times">Times</option>
	</select>
	
	<input type="text" bind:value={text} placeholder="Skriv noe">
	<p style ="font-size: {size}px; color: {color}; font-family: {type}; ">{text}</p>

</main>



<style>
	main {
		padding-bottom: 4rem;
	}
	
</style>




