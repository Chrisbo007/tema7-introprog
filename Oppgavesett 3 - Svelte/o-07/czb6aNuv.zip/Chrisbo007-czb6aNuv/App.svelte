<script>
	
	let y;
	$: skala = y / 50;
	
</script>

<svelte:window bind:scrollY={y} />
<main>
	
	<div style="transform: rotate({y}deg) scale({y})"></div>
	<div style="transform: rotate({y}deg)"></div>
	
</main>

<style>
	div {
		width: 20px;
		height: 20px;
		background-color: yellow;
		position: fixed;
		left: calc(50% - 10px);
		top: calc(50% - 10px);
	}

	main {		
		height: 500vh;
	}
	
	
</style>


