
<script>
  let navn = ""
</script>

<input bind:value={navn}>
<div>{navn}</div>


<style>
	div {
		margin-top: 1rem;
	}
</style>