<script>
	let url = "";
	let title = "";
	let width = "";
	
</script>

<input type="text" bind:value={title} placeholder="Skriv en tittel">
<input type="number" bind:value={width} placeholder="Bredden på bildet">
<input type="text" bind:value={url} placeholder="Lim inn url">

<h1>{title}</h1>

<img src="{url}" alt="{title}" width="{width}">




