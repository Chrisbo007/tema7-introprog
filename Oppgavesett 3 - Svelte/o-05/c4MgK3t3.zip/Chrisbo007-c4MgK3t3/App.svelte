<script>
	let pris ="";
	

</script>

<input type="number" bind:value={pris} placeholder="Pris">


<p>Pris uten moms: {pris} kr</p>
<p>Moms: 25% </p>
<p>Pris inkl moms: {pris*1.25} kr</p>


<style>
</style>


