

<script>
	let url = "https://swapi.co/api/films"
	

	let filmer = []
	
	const getFilmer = async () => {
		
		const response = await fetch(url)
		const json = await response.json()
		filmer = json.results
		console.log(filmer)
	}

	getFilmer()
	
</script>

<h1>Star Wars-Filmer</h1>

<div>
   {#each filmer as film }
            <h1>
             {film.title}
            </h1>
			<p>
			{film.opening_crawl}	
			</p>
        {/each}
</div>

<style>
	div {
	column-count:2;	
	}
</style>
