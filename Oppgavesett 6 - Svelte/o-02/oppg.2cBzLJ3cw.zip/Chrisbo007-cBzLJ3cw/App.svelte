

<script>
	let url = "https://swapi.co/api/people/1/"


	let person = undefined
	
	const getPerson = async () => {
		
		const response = await fetch(url)
		const json = await response.json()
		person = json
		console.log(person)
	}

	getPerson()
	
</script>

{#if person}
	<h1>{person.name}</h1>
	<p><strong>Gender:</strong> {person.gender}</p>
	<p><strong>Height:</strong> {person.height} cm</p>
	<p><strong>mass:</strong> {person.mass}</p>
	<p><strong>Hair Color:</strong> {person.hair_color}</p>
	<p><strong>Eye color:</strong> {person.eye_color}</p>
	
	{:else}
	Loading...

{/if}

<style>
	
</style>
