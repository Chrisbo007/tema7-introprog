<script>
	let reiser = []

	
	const getReiser = async () => {
		const response = await fetch("./import.json")
		const json = await response.json()
		reiser = json.reiser
		console.log(reiser)
	}
	
	getReiser()
	
</script>

<h1>En liste over reiser</h1>
<ul>
	{#each reiser as reise}
		<li>{reise.land}</li>
	{:else}
		<li>Laster reiser...</li>
	{/each}	
</ul>
<style>

	
</style>
