<script>
	
	let klasse = "faller"
	
	let tall1 = 9
	let tall2 = 5
	$: fasit = tall1 * tall2
	let svar = ""
	let theGameIsOn = true
	$: riktigsvar = (fasit === svar)
	$: regnestykke = `${tall1} x ${tall2}`
	let poeng = 0
	
	const lagNyeTall = () => {
		tall1 =  Math.ceil(Math.random() * 10)
		tall2 =  Math.ceil(Math.random() * 10)
	}
	
	const sjekkSvar = () => {
		if(riktigsvar && theGameIsOn) {
			lagNyeTall()
			svar = ""	
			klasse = ""
			poeng++
			setTimeout( () => { klasse = "faller" }, 50 )
		}
	}
	
	const gameOver = () => {
		theGameIsOn = false
		console.log("GAME OVER")	
	}
	
	const PlayAgain = () => {
		console.log("Play again")
		theGameIsOn = true	
		poeng = 0
	}
	
	
</script>


<section>
	<header>
		<div>Poeng: {poeng}</div>
	</header>	
	
	<main>
		{#if theGameIsOn}
			<div on:animationend={gameOver} class="{klasse}">{regnestykke}</div>
			<hr>	
		<footer>
			<input type="number" bind:value={svar} on:input={sjekkSvar}>
		</footer>
		{:else}
		<div id="GameOver"><span>Game Over</span></div>
		<div id="restart" on:click={PlayAgain}><span>Play Again</span></div>
		{/if}	
	</main>
	
	
	
</section>

<style>

	header {
		padding: 2rem;
		text-align: center;
		font-size: 1.5rem;
		font-weight: 800;
	}
	@keyframes fallNed {
		to {
			transform: translateY(500px);
		}
	}

	.faller {
		animation: fallNed 4s linear forwards;
	}

	main div {
		width: 200px;
		height: 50px;
		line-height: 50px;
		margin: 10px auto;
		background-color: lightcoral;
		text-align: center;
		font-size: 2rem;
		border-radius: 10px;
	}	
	
	hr {
		position: absolute;                  
        bottom: 130px; 
		width: 100%;
		border: 1px dashed yellow;
	}
	
	#GameOver {
		width: 250px;
		background-color: lightskyblue;
		font-size: 1.5rem;
		border-radius: 10px;
		padding: 1rem;
		font-weight: 700;
	}
	
	#restart {
		width: 250px;
		background-color: MediumSpringGreen;
		font-size: 2rem;
		border-radius: 10px;
		padding: 1rem;
	}
	
	
	input {
		padding: 1rem;
		border-radius: 20px;
		font-size: 1.5rem;
		text-align: center;
	}
	footer {
		position: absolute;                  
        bottom: 40px; 
		width: 100%;
		text-align:center;
	}
	
</style>